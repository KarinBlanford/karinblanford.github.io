import java.util.Arrays;

public class Album {
	private Song[] songList;
	private String albumArtist;
	private String albumGenre;
	private String albumName;

	public Album(Song[] songList, String albumArtist, String albumGenre, String albumName) {
		setSongList(songList);
		setAlbumArtist(albumArtist);
		setAlbumGenre(albumGenre);
		setAlbumName(albumName);
	}

	public Song[] getSongList() {
		return songList;
	}

	private void setSongList(Song[] songList) {
		this.songList = songList;
	}

	public String getAlbumArtist() {
		return albumArtist;
	}

	private void setAlbumArtist(String albumArtist) {
		this.albumArtist = albumArtist;
	}

	public String getAlbumGenre() {
		return albumGenre;
	}

	private void setAlbumGenre(String albumGenre) {
		this.albumGenre = albumGenre;
	}

	public String getAlbumName() {
		return albumName;
	}

	private void setAlbumName(String albumName) {
		this.albumName = albumName;
	}

	public String toString() {
		return "Album [songList=" + Arrays.toString(songList) + ", albumArtist=" + albumArtist + ", albumGenre="
				+ albumGenre + ", albumName=" + albumName + "]";
	}
}
