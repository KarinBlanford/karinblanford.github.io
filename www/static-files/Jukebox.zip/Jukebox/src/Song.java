
public class Song {

	private String songTitle;
	private double songLength;
	private String songArtist;
	private String albumName;
	
	public Song(String songTitle, double songLength, String songArtist, String albumName) {
		setSongTitle(songTitle);
		setSongLength(songLength);
		setSongArtist(songArtist);
		setAlbumName(albumName);
	}

	public String getSongTitle() {
		return songTitle;
	}

	private void setSongTitle(String songTitle) {
		this.songTitle = songTitle;
	}

	public double getSongLength() {
		return songLength;
	}

	private void setSongLength(double songLength) {
		this.songLength = songLength;
	}

	public String getSongArtist() {
		return songArtist;
	}

	private void setSongArtist(String songArtist) {
		this.songArtist = songArtist;
	}

	public String getAlbumName() {
		return albumName;
	}

	private void setAlbumName(String albumName) {
		this.albumName = albumName;
	}

	public String toString() {
		//“<songTitle> is by <songArtist> and is <songLength> minutes long”
		int minutes = (int) Math.floor(songLength);
		double seconds = songLength - minutes;
		int wholeSeconds = (int) Math.round(seconds * 60);
		String strSeconds = Integer.toString(wholeSeconds);
		if (wholeSeconds < 10) {
			strSeconds = "0" + strSeconds;
		}
		String _songLength = minutes + ":" + strSeconds;
		return songTitle + " is by " + songArtist + " and is " + _songLength + " minutes long";
	}
	
	public boolean equals(Song otherSong) {
		return this.getSongTitle().equals(otherSong.getSongTitle()) && this.getSongArtist().equals(otherSong.getSongArtist()) && this.getSongLength() == otherSong.getSongLength();
	}
}
