
public class JukeboxPlayer {

	public static void main(String[] args) {
		Song someSong = new Song("It's the end of the world as we know it", 0, null, null);

	}

}
